## Content Management Tool
🚀Project Update🚀<br>
Here's my TASK-1  "Content Management Tool" as part of my Internship with Bharat Intern.

<a href="https://epavan162.github.io/Content-Management-Tool/" target="_blank"><br>
🚀**Visit Now** 🚀</a>
![logo](https://github.com/epavan162/Content-Management-Tool/assets/102135027/4b88a83e-adcb-4949-ae6f-9e50aa1ee94f)

## 📌 Home Page of Content Management Tool 🙈 :


![Screenshot 2023-09-04 150420](https://github.com/epavan162/Content-Management-Tool/assets/102135027/e81270cd-f445-4a45-abb0-db3c2642953f)


<h3>If you want to know more about my Project </3>
<a href="https://epavan162.github.io/Content-Management-Tool/" target="_blank"> &emsp;🚀 **Visit Now** 🚀</a>

<h2>📬 Contact</h2>


If you want to contact me, you can reach me through below handles.<br>

<a href="https://www.linkedin.com/in/edagottu-pavan-kalyan-281681236/"><img alt="LinkedIn" src="https://img.shields.io/badge/linkedin-%230077B5.svg?style=for-the-badge&logo=linkedin&logoColor=white"/></a>
<a href="mailto:epavan162@gmail.com"><img alt="Gmail" src="https://img.shields.io/badge/Gmail-D14836?style=for-the-badge&logo=gmail&logoColor=white"/></a>
<a href="https://www.instagram.com/mr_innocent_kid420"><img alt="Instagram" src="https://img.shields.io/badge/Instagram-E4405F?style=for-the-badge&logo=instagram&logoColor=white"/></a>
<a href="https://t.me/edagottupavankalyan162"><img alt="Telegram" src="https://img.shields.io/badge/Telegram-2CA5E0?style=for-the-badge&logo=telegram&logoColor=white" /></a>


© 2023 Edagottu Pavan Kalyan



